package org.medex.beans;

public class BookAppointment {
	
	String  id,specialist,date_of_app,timeslot, time_of_app,doctorid;
	public BookAppointment(String id, String specialist, String date_of_app,
			String timeslot, String time_of_app, 
			String doctorid) {
		super();
		this.id = id;
		this.specialist = specialist;
		this.date_of_app = date_of_app;
		this.timeslot = timeslot;
		this.time_of_app = time_of_app;
		this.doctorid = doctorid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSpecialist() {
		return specialist;
	}
	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}
	public String getDate_of_app() {
		return date_of_app;
	}
	public void setDate_of_app(String date_of_app) {
		this.date_of_app = date_of_app;
	}
	public String getTimeslot() {
		return timeslot;
	}
	public void setTimeslot(String timeslot) {
		this.timeslot = timeslot;
	}
	public String getTime_of_app() {
		return time_of_app;
	}
	public void setTime_of_app(String time_of_app) {
		this.time_of_app = time_of_app;
	}
	
	public String getDoctorid() {
		return doctorid;
	}
	public void setDoctorid(String doctorid) {
		this.doctorid = doctorid;
	}
	
	
	
      
}
