package org.medex.beans;

public class Feedback {
	String name;
	String email;
	String subjectLine;
	String msg;
	public Feedback()
	{
		
	}
	
	public Feedback(String name, String email, String subjectLine, String msg) {
		super();
		this.name = name;
		this.email = email;
		this.subjectLine = subjectLine;
		this.msg = msg;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSubjectLine() {
		return subjectLine;
	}
	public void setSubjectLine(String subjectLine) {
		this.subjectLine = subjectLine;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	

}
