package org.medex.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import org.medex.service.CancelAppointmentService;
import org.medex.service.CancelAppointmentServiceImpl;


@WebServlet("/CancelAppointmentServlet")
public class CancelAppointmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	CancelAppointmentService can_ser=new CancelAppointmentServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 PrintWriter out=response.getWriter();
		 int id=Integer.parseInt(request.getParameter("cancel_name"));
		 String res=can_ser.cancelAppointment(id);
		 if(res!=null)
		 {
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Appointment canceled successfully');");
				   out.println("location='index.jsp';");
				   out.println("</script>");
			
		 }
		 else
		 {
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Appointment not canceled');");
				   out.println("location='index.jsp';");
				   out.println("</script>");
		 }
	}

}
