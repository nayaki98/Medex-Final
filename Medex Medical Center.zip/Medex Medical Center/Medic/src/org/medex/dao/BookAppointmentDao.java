package org.medex.dao;



import org.medex.beans.BookAppointment;

public interface BookAppointmentDao {

	boolean showavailableDoctor(BookAppointment ba);

}
