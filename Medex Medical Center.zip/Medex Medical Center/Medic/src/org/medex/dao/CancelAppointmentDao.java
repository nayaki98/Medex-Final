package org.medex.dao;

public interface CancelAppointmentDao {
	String cancelAppointment(int id);

}
