package org.medex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.medex.util.DBConstants;
import org.medex.util.DBUtil;



public class CancelAppointmentDaoImpl implements CancelAppointmentDao{
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	@Override
	public String cancelAppointment(int id) {
		String res="";
		int r = 0;
		try {
			  con =(Connection) DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
                      DBConstants.UNAME, DBConstants.PWD);
			pst=con.prepareStatement("delete from Appointment where id=?");
			pst.setInt(1, id);
			r=pst.executeUpdate();
			
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(r>0)
			res="deleted";
		else
			res=null;
		
		System.out.println(res);
		return res;
			
	}
		

}
