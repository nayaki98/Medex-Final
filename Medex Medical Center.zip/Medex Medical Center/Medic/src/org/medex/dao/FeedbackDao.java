package org.medex.dao;

import java.util.List;

import org.medex.beans.Feedback;

public interface FeedbackDao {
	
	void feedbackFormRegister(Feedback f);
	

}
