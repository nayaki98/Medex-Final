package org.medex.service;

import java.util.List;

import org.medex.beans.BookAppointment;

public interface BookAppointmentService {
	
boolean showavailableDoctor(BookAppointment ba);
}
