package org.medex.service;



public interface CancelAppointmentService {
	String cancelAppointment(int id);

}
