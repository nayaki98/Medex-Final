package org.medex.service;

import org.medex.dao.CancelAppointmentDao;
import org.medex.dao.CancelAppointmentDaoImpl;


public class CancelAppointmentServiceImpl implements CancelAppointmentService {

	CancelAppointmentDao dao=new CancelAppointmentDaoImpl();
	
	@Override
	public String cancelAppointment(int id) {
		
		String res=dao.cancelAppointment(id);
		
		return res;
	}

	

}
