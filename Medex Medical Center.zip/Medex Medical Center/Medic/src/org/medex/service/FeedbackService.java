package org.medex.service;



import org.medex.beans.Feedback;

public interface FeedbackService {
	void feedbackForm(Feedback f);
	
}
