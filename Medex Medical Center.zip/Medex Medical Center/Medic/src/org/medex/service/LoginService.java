package org.medex.service;

import org.medex.beans.User;

public interface LoginService {
	User validateUser(User u);

}
